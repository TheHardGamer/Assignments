//Static binary tree traversanl,150299, 16/02
#include <stdio.h>
#include <stdlib.h>

struct tree {
	char info;
	struct tree *left;
	struct tree *right;
};

inline int preorder(struct tree *);
inline int inorder(struct tree *);
inline int postorder(struct tree *);

int main() {
	struct tree *root = (struct tree*)malloc(sizeof(struct tree));
	struct tree *a,*b,*c,*d,*e,*f;
	a = (struct tree*)malloc(sizeof(struct tree));
	b = (struct tree*)malloc(sizeof(struct tree));
	c = (struct tree*)malloc(sizeof(struct tree));
	d = (struct tree*)malloc(sizeof(struct tree));
	e = (struct tree*)malloc(sizeof(struct tree));
	f = (struct tree*)malloc(sizeof(struct tree));
	root->info = 'A';
	a->info = 'B';
	b->info = 'C';
	c->info = 'D';
	d->info = 'E';
	e->info = 'F';
	f->info = 'G';
	root->left = a;
	root->right = b;
	a->left = c;
	a->right = d;
	b->left = e;
	b->right = f;
	printf("Preorder:\n");
	preorder(root);
	printf("\n");
	printf("Inorder:\n");
	inorder(root);
	printf("\n");
	printf("Postorder:\n");
	postorder(root);
	printf("\n");
}

int preorder(struct tree *root) {
	printf("%c ",root->info);
	if(root->left != NULL) {
		preorder(root->left);
	}
	if(root->right != NULL) {
		preorder(root->right);
	}
	return 0;
}

int inorder(struct tree *root) {
	if(root->left != NULL) {
		inorder(root->left);
	}
	printf("%c ",root->info);
	if(root->right != NULL) {
		inorder(root->right);
	}
	return 0;
}

int postorder(struct tree *root) {
	if(root->left != NULL) {
		postorder(root->left);
	}
	if(root->right != NULL) {
		postorder(root->right);
	}
	printf("%c ",root->info);
	return 0;
}


