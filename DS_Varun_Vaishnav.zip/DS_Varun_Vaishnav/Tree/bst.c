#include <stdio.h>
#include <stdlib.h>

struct tree {
    int info;
    struct tree *right;
    struct tree *left;
};

inline struct tree* search(struct tree *root, int x);
inline struct tree* find_minimum(struct tree *);
inline struct tree* new_tree(int);
inline struct tree* insert(struct tree *, int);
inline struct tree* delete(struct tree *,int);
inline void inorder(struct tree *);

int main()
{
	int elements = 0, a = 0;
	printf("Enter total number of elements:\n");
	scanf("%d",&elements);
	printf("Enter root/top most node\n");
	scanf("%d",&a);
	struct tree *root,*temp;
	root = (struct tree *)malloc(sizeof(struct tree));
	root->info = a;
	root->left = NULL;
	root->right = NULL;
	a = 0;
	elements -= 1;
	printf("Enter rest of the tree elements\n");
	while(elements > 0){
		scanf("%d",&a);
		insert(root,a);
		elements--;
	}
	printf("Inorder:\n");
	inorder(root);
	printf("\n");
	a = 0;
	int b = 0, c = 10;
	while(c > 0) {
		printf("\nEnter 1 to delete element, 2 to search, 3 to insert, 4 to print inorder, 0 to exit\n");
		scanf("%d",&c);
		switch(c) {
			case 1:
				b = 0;
				printf("Enter element to delete\n");
				scanf("%d",&b);
				delete(root,b);
				break;
			case 2:
				b = 0;
				printf("Enter element to search\n");
				scanf("%d",&b);
				temp = search(root,b);
				if(temp != NULL){printf("Element found\n");}else{printf("Element not found\n");}
				break;
			case 3:
				b = 0;
				printf("Enter element to insert\n");
				scanf("%d",&b);
				insert(root,b);
				break;
			case 4:
				inorder(root);
				break;
			case 0:
				c = 0;
				break;
			default:
				printf("Enter a valid operation\n");
				break;
		}
	}
	return 0;
}

struct tree* search(struct tree *root, int x) {
	if(root==NULL || root->info==x){ return root; }
	else if(x>root->info) { return search(root->right, x); }
	else { return search(root->left,x); }
}

struct tree* find_minimum(struct tree *root) {
	if(root == NULL) { return NULL; }
	else if(root->left != NULL) { return find_minimum(root->left); }
	return root;
}

struct tree* new_tree(int x) {
	struct tree *p;
	p = malloc(sizeof(struct tree));
	p->info = x;
	p->left = NULL;
	p->right = NULL;
	return p;
}

struct tree* insert(struct tree *root, int x) {
	if(root==NULL) { return new_tree(x); }
	else if(x>root->info) { root->right = insert(root->right, x);}
	else { root->left = insert(root->left,x); }
	return root;
}

struct tree* delete(struct tree *root, int x) {
	if(root==NULL){ return NULL; }
	if (x>root->info) {
		root->right = delete(root->right, x);
	}
	else if(x<root->info) {
		root->left = delete(root->left, x);
	}
	else {
		if(root->left==NULL && root->right==NULL) {
			free(root);
			return NULL;
		}
		else if(root->left==NULL || root->right==NULL) {
			struct tree *temp;
			if(root->left==NULL) {
				temp = root->right;
			} else {
				temp = root->left;
				free(root);
				return temp;
			}
		}
		else {
				struct tree *temp = find_minimum(root->right);
				root->info = temp->info;
				root->right = delete(root->right, temp->info);
		}
	
	}
	return root;
}

void inorder(struct tree *root) {
	if(root!=NULL) {
		inorder(root->left);
		printf(" %d ", root->info);
		inorder(root->right);
	}
}


