#include <stdio.h>
#include <stdlib.h>

struct node{
	int info;
	struct node *link;
};
struct node *head;

inline int ibegin(int x);
inline int iend(int x);
inline int ipos(int x, int y);
inline int dbegin();
inline int dend();
inline int dpos(int y);
inline int display();

int main() {
	int a,x=0,y=0;
	while(a!=0){
		printf("Simple linked list\n");
		printf("Enter 1 to insert at beginning,2 to insert at end,3 to insert at any given position, 4 to delete from beginning, 5 to delete from end, 6 to delete from given position, 7 to display ll, 0 to exit.\n");
		scanf("%d",&a);
		switch(a){
			case 1:
				printf("Enter element to insert at first pos:\n");
				scanf("%d",&x);
				ibegin(x);
				break;
			case 2:
				printf("Enter element to insert at last pos:\n");
				scanf("%d",&x);
				iend(x);
				break;
			case 3:
				printf("Enter element to insert and position:\n");
				scanf("%d %d",&x,&y);
				ipos(x,y);
				break;
			case 4:
				printf("Deleting from first position\n");
				dbegin();
				break;
			case 5:
				printf("Deleting from end\n");
				dend();
				break;
			case 6:
				printf("Enter position to delete element from\n");
				scanf("%d",&y);
				dpos(y);
				break;
			case 7:
				display();
				break;
			case 0:
				return 0;
				break;
			default:
				printf("Enter a valid operation\n");
				break;
		}
	}
	return 0;
}

int ibegin(int x){
	struct node *p;
	p = (struct node *)malloc(sizeof(struct node));
	if(p==NULL){
		return 0;
	}
	else{
		p->info = x;
		p->link = head;
		head = p;
	}
	return 0;
}

int iend(int x){
	struct node *p, *temp;
	p = (struct node *)malloc(sizeof(struct node));
	if(p==NULL){
		return 0;
	}
	else {
		p->info = x;
		if(head == NULL){
			p->link = NULL;
			head = p;
		}
		else{
			temp=head;
			while(temp->link != NULL) {
				temp = temp->link;
			}
			temp->link = p;
			p->link = NULL;
		}
	}
	return 0;
}

int ipos(int x, int y){
	int i =0;
	struct node *p, *temp;
	p = (struct node *)malloc(sizeof(struct node));
	if(p==NULL){ return 0;}
	else {
		p->info = x;
		temp = head;
		for(i=0;i<y;i++){
			temp = temp->link;
			if(temp == NULL){ return 0;}
		}
		p->link=temp->link;
		temp->link = p;
	}
	return 0;
}

int dbegin(){
	struct node *p;
	if(head == NULL){return 0;}
	else{
		p=head;
		head = p->link;
		free(p);
	}
	return 0;
}

int dend() {
	struct node *p, *p1;
	if(head == NULL){return 0;}
	else if(head->link == NULL){
		head = NULL;
		free(head);
	}
	else {
		p=head;
		while(p->link != NULL){
			p1 = p;
			p = p->link;
		}
		p1->link = NULL;
		free(p);
	}
	return 0;
}

int dpos(int y){
	int i =0;
	struct node *p, *p1;
	p = head;
	for(i=0;i<y;i++){
		p1 = p;
		p = p->link;
		if(p == NULL){ return 0; }
	}
	p1->link = p->link;
	free(p);
	return 0;
}

int display(){
	struct node *p;
	p = head;
	if(p == NULL){ printf("Empty LL\n"); return 0;}
	else {
		printf("The LL is\n");
		while(p != NULL){
			printf("%d\n",p->info);
			p = p->link;
		}
	}
	return 0;
}
