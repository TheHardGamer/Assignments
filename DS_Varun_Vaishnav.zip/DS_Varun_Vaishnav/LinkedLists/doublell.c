#include <stdio.h>
#include <stdlib.h>

struct node{
	int info;
	struct node *next;
	struct node *prev;
};

inline int llsize(struct node*);
inline int ibegin(struct node**, int);
inline int iend(struct node**, int);
inline int ipos(int, int, struct node**);
inline int display(struct node*);
inline int delete(struct node**, int);

int main()
{
	struct node* head = NULL;
	int a,x=0,y=0;
	while(a!=0){
		printf("Enter 1 to insert at beginning,2 to insert at end,3 to insert at any given position, 4 to delete, 5 to display ll, 0 to exit.\n");
		scanf("%d",&a);
		switch(a){
			case 1:
				printf("Enter element to insert at first pos:\n");
				scanf("%d",&x);
				ibegin(&head,x);
				break;
				case 2:
				printf("Enter element to insert at last pos:\n");
				scanf("%d",&x);
				iend(&head,x);
				break;
			case 3:
				printf("Enter element to insert and position[The position starts from 0]:\n");
				scanf("%d %d",&x,&y);
				ipos(x,y,&head);
				break;
			case 4:
				printf("Enter integer/element to delete\n");
				scanf("%d",&x);
				delete(&head,x);
				break;
			case 5:
				display(head);
				break;
			case 0:
				return 0;
				break;
			default:
				printf("Enter a valid operation\n");
				break;
		}
	}
	return 0;
}

int llsize(struct node* node){
	int size=0;
	while(node!=NULL){
		node = node->next;
		size++;
	}
	return size;
}

/* For inserting at position, the given position from user should start from 0*/
int ipos(int info, int pos, struct node** head)
{
	int size = llsize(*head);
	printf("%d",size);
	if(pos<1 || size <= pos) {
		printf("Invalid Position\n");
		return 0; 
	}
	else {
		struct node* temp = *head;
		struct node* newnode = (struct node*) malloc(sizeof(struct node));
		newnode->info = info;
		newnode->next = NULL;
		while(--pos) {
			temp=temp->next;
		}
		struct node* temp2 = temp->next;
		newnode->next= temp->next;
		newnode->prev = temp;
		temp->next = newnode;
		temp2->prev = newnode;
	}
	return 0;
}

int iend(struct node** head, int info){
	struct node* newnode = (struct node*)malloc(sizeof(struct node));
	newnode->info = info;
	newnode->next = NULL;
	
	if(*head==NULL){
		*head = newnode;
		newnode->prev = NULL;
	}
	
	struct node* temp = *head;
	
	while(temp->next!=NULL) {
		temp = temp->next;
	}
	temp->next = newnode;
	newnode->prev = temp;
	return 0;
}

int ibegin(struct node** head, int info){
	struct node* newnode = (struct node*) malloc(sizeof(struct node));
	newnode->info = info;
	newnode->next = *head;
	newnode->prev = NULL;
	
	if(*head !=NULL) {
		(*head)->prev = newnode;
	}
	*head = newnode;
	return 0;
}

int delete(struct node** head, int x)
{
	struct node* temp = *head;
	struct node* previous = (struct node*) malloc(sizeof(struct node));
	
	if(temp->next == NULL) {
		*head = NULL;
		free(temp);
		printf("%d deleted\n",x);
		return 0;
	}
	if(temp!=NULL && temp->info==x) {
		*head = temp->next;
		(*head)->prev = NULL;
		free(temp);
		printf("%d deleted\n",x);
		return 0;
	}
	while (temp != NULL && temp->info != x) {
		previous = temp;
		temp = temp->next;
	}
	if(temp==NULL) {
		printf("Value not found\n");
		return 0;
	}
	previous->next = temp->next;
	if(temp->next == NULL) {
		printf("%d deleted\n",x);
		free(temp);
		return 0;
	}
	struct node* temp2 = (struct node*)malloc(sizeof(struct node));
	temp2 = temp->next;
	temp2->prev = previous;
	free(temp);
	printf("%d deleted\n",x);
	return 0;
}

int display(struct node* node) 
{
	struct node *end;
	if(node == NULL){printf("Empty list\n");return 0;}
	printf("LL: ");
	while (node != NULL) {
		printf(" %d ", node->info);
		end = node;
		node = node->next;
	}
	printf("\n");
	return 0;
}
