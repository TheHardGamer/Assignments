#include <stdio.h>
#include <stdlib.h>

struct node{
	int info;
	struct node *link;
};
struct node *head;

inline int ibegin(int x);
inline int iend(int x);
inline int dbegin();
inline int dend();
inline int reverse();
int display();

int main() {
	int a,x=0,y=0;
	while(a!=0){
		printf("Enter 1 to insert at beginning,2 to insert at end,3 to delete from beginning, 4 to delete from end, 5 to display ll, 6 to reverse, 0 to exit.\n");
		scanf("%d",&a);
		switch(a){
			case 1:
				printf("Enter element to insert at first pos:\n");
				scanf("%d",&x);
				ibegin(x);
				break;
			case 2:
				printf("Enter element to insert at last pos:\n");
				scanf("%d",&x);
				iend(x);
				break;
			case 3:
				printf("Deleting from first position\n");
				dbegin();
				break;
			case 4:
				printf("Deleting from end\n");
				dend();
				break;
			case 5:
				display();
				break;
			case 6:
				reverse();
				break;
			case 0:
				return 0;
				break;
			default:
				printf("Enter a valid operation\n");
				break;
		}
	}
	return 0;
}

int ibegin(int x){
	struct node *p, *temp;
	p = (struct node *)malloc(sizeof(struct node));
	if(p==NULL){
		return 0;
	}
	else{
		p->info = x;
		if(head == NULL){
			head = p;
			p->link = head;
		}
		else{
			temp = head;
			while(temp->link != head){
				temp = temp->link;
			}
			p->link = head;
			temp->link = p;
			head = p;
		}
	}
	return 0;
}

int iend(int x){
	struct node *p, *temp;
	p = (struct node *)malloc(sizeof(struct node));
	if(p==NULL){
		return 0;
	}
	else {
		p->info = x;
		if(head == NULL){
			head = p;
			p->link = head;
		}
		else{
			temp=head;
			while(temp->link != head) {
				temp = temp->link;
			}
			temp->link = p;
			p->link = head;
		}
	}
	return 0;
}

int dbegin(){
	struct node *p;
	if(head == NULL){return 0;}
	else if(head->link == head){
		head = NULL;
		free(p);
		return 0;
	}
	else{
		p = head;
		while(p->link != head){
			p = p->link;
		}
		p->link = head->link;
		free(head);
		head = p->link;
	}
	return 0;
}

int dend() {
	struct node *p, *p1;
	if(head == NULL){return 0;}
	else if(head->link == head){
		head = NULL;
		free(head);
		return 0;
	}
	else {
		p=head;
		while(p->link != head){
			p1 = p;
			p = p->link;
		}
		p1->link = p->link;
		free(p);
	}
	return 0;
}

int reverse()
{
	struct node *prev, *cur, *link, *last;
	printf("Reverse LL:\n");
	if (head == NULL) {
		printf("Empty LL.\n");
		return 0;
	}
	last = head;
	prev = head;
	cur = (head)->link;
	head = (head)->link;
	while (head != last) {
		head = head -> link;
		cur->link = prev;
		prev = cur;
		cur = head;
	}
	cur->link = prev;
	head = prev;
	display();
	return 0;
}

int display(){
	struct node *p;
	int i=1;
	if(head == NULL){ printf("Empty LL\n"); return 0;}
	else {
		p = head;
		printf("The LL is\n");
		do {
			printf("%d\n",p->info);
			p = p->link;
			i++;
		} while(p != head);
	}
	return 0;
}
