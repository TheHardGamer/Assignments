/* Author: Varun Vaishnav(150299), Shift 1, Track 2 */

/* This question was particulary a bit tricky one, for ex. if the parents file contained a father named for ex. Rooney,
and if Rooney had 2 sons like luke and wayne and those 2 had 1 child each, so that would mean Rooney actually has TWO
grandchildren, the first solution that struct my mind was to simply traverse through father names and strcmp, but it will
fail in the given above scenario, so I had to come up with this a bit complex solution.*/
#include <stdio.h>
#include <string.h>

struct parents{
	char s[100];
	char f[100];
};

int main() {
	FILE *file;
	file=fopen("parents.txt", "r");
	char ch;
	int count = 0,i = 0,j=0,k=0,a=0;
	do{
		ch = fgetc(file);
		if (ch == '\n') count++;
	} while (ch != EOF);
        rewind(file);
        struct parents p[count];
	for(i=0;i<count;i++){
		fscanf(file,"%s %s\n",p[i].s,p[i].f);
	}
	printf("Enter father's name whose grandchildren need to be counted[lowercase]:\n");
	char fname[100],sname[100];
	scanf("%s",fname);
	char temp[100][100],temp1[100][100],temp2[100][100];	
	i=0;
	for(j=0;j<count;j++){
		strcpy(temp[i],p[j].f);
		i++;
	}
	i=0;
	for(j=0;j<count;j++){
		strcpy(temp1[i],p[j].s);
		i++;
	}
	i=0;
	for(j=0;j<count;j++){
		if(strcmp(fname,temp[i]) == 0){
			strcpy(temp2[i],temp1[i]);
		}
		i++;
	}	
	for(k=0;k<i;k++){
		for(j=0;j<count;j++){
			if(strcmp(temp2[k], temp[j]) == 0){
				a += 1;
			}
		}
	}
	if(a > 0){
		printf("%d grandchildren\n",a);
	}
	else{printf("No grandchildren\n");}
	fclose(file);
	return 0;
}
