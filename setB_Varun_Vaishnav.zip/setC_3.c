#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdint.h>

inline int reversebits(unsigned int *, uint32_t *);

int main() 
{
	unsigned int a;
	uint32_t aa;
	printf("Unsigned int values range: %u\n", (unsigned int) UINT_MAX);
	printf("Enter a number to convert to decimal\n");
	scanf("%u", &a);
	aa = a;
	reversebits(&a,&aa);
	return 0;
}

int reversebits(unsigned int *a, uint32_t *aa) {
	unsigned int b,c,d;
	int i, count = 0;
	c = *a;
	for(i = 0; c > 0; i++) {
		d = c % 2;
		c = c / 2;
		count++;
	}
	unsigned int *e;
	e = (unsigned int *)malloc(count * sizeof(unsigned int));
	for(i = 0; *a > 0; i++) {
		e[i] = *a % 2;
		*a = *a / 2;
	}
	
	printf("The value in bits before reversing is:\n");
	for(int j=i-1; j>=0; j--){
		printf("%u",e[j]);
	}
	printf("\n");
	printf("After reversing:\n");
	for(i=0;i<count;i++){
		printf("%u",e[i]);
	}
	printf("\n");
	
	printf("Bits in unsigned 32 bit int before reversing:\n");
	for (uint32_t i = 0;i<32;++i) {
		printf("%u", (*aa>>i) & 1);
	}
	uint32_t reverse;
	for (uint32_t i = 0;i<32;++i) {
		uint8_t i_bit_value = (*aa >> i) & 1;
		reverse |= i_bit_value << (31-i) ;
	}
	printf("\nAfter reversing:\n");
	for (uint32_t i = 0;i<32;++i) {
		printf("%u", (reverse>>i) & 1);
	}
	printf("\n");
	
	return 0;
}
