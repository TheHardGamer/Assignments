#include <stdio.h>
#include <stdlib.h>
#include <string.h>

inline int del(int);
char *input;

int main()
{
	printf("Enter length of the string and the string:\n");
	int length = 0, i = 0, j = 0;
	scanf("%d",&length);
	if(length == 0){printf("Enter a valid length\n");return 0;}
	//Alternatively, we can simply take the input string in a
	//huge char array and then use strlen to get the length
	//of the string, but it will be a waste of memory for
	//most of the time if the char isn't completely filled.
	input = (char *)malloc(length * sizeof(char));
	scanf("%s",input);
	if(strlen(input) != length){printf("Entered string length and the actual string length don't match!\n");return 0;}
	for(;i<length;){
		if((input[i] == input[i+1] ) && (i >= 0) && input[i] != '\0'){
			del(i);
			i--;
		}
		else { i++; }
	}
	if(strlen(input) == 0) {
		printf("Empty String.\n");
	} else {
		printf("Reduced String is:\n");
		printf("%s \n",input);
	}
	return 0;
}

int del(int i) {
	for(;input[i]!='\0';) {
		input[i]=input[i+2];
		input[i+1]=input[i+3];
		i+=2;
	}
	return 0;
}
